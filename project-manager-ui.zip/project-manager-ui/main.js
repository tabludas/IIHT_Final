(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _components_project_add_project_add_project_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/project/add-project/add-project.component */ "./src/app/components/project/add-project/add-project.component.ts");
/* harmony import */ var _components_task_add_task_add_task_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/task/add-task/add-task.component */ "./src/app/components/task/add-task/add-task.component.ts");
/* harmony import */ var _components_user_add_user_add_user_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/user/add-user/add-user.component */ "./src/app/components/user/add-user/add-user.component.ts");
/* harmony import */ var _components_task_view_task_view_task_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/task/view-task/view-task.component */ "./src/app/components/task/view-task/view-task.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    { path: 'addProject', component: _components_project_add_project_add_project_component__WEBPACK_IMPORTED_MODULE_2__["AddProjectComponent"] },
    { path: 'addTask', component: _components_task_add_task_add_task_component__WEBPACK_IMPORTED_MODULE_3__["AddTaskComponent"] },
    { path: 'addUser', component: _components_user_add_user_add_user_component__WEBPACK_IMPORTED_MODULE_4__["AddUserComponent"] },
    { path: 'viewTask', component: _components_task_view_task_view_task_component__WEBPACK_IMPORTED_MODULE_5__["ViewTaskComponent"] }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div style=\"margin: 25px\">\n  <h2 class=\"appHead\">{{title}}</h2>\n  <ul class=\"nav\">\n    <li class=\"nav-item\">\n      <a id=\"addProject\" class=\"nav-link\" routerLink=\"/addProject\" routerLinkActive=\"active\" style=\"padding-left: 0\">Add Project</a>\n    </li>\n    <li class=\"nav-item\">\n     <a id=\"addTask\" class=\"nav-link\" routerLink=\"/addTask\" routerLinkActive=\"active\">Add Task</a>\n   </li>\n   <li class=\"nav-item\">\n    <a id=\"addUser\" class=\"nav-link\" routerLink=\"/addUser\" routerLinkActive=\"active\">Add User</a>\n  </li>\n  <li class=\"nav-item\">\n    <a id=\"viewTask\" class=\"nav-link\" routerLink=\"/viewTask\" routerLinkActive=\"active\">View Task</a>\n  </li> \n  </ul>\n</div>\n<router-outlet></router-outlet>"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'Project Manager';
    }
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _components_project_add_project_add_project_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/project/add-project/add-project.component */ "./src/app/components/project/add-project/add-project.component.ts");
/* harmony import */ var _components_task_add_task_add_task_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/task/add-task/add-task.component */ "./src/app/components/task/add-task/add-task.component.ts");
/* harmony import */ var _components_user_add_user_add_user_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components/user/add-user/add-user.component */ "./src/app/components/user/add-user/add-user.component.ts");
/* harmony import */ var _components_task_view_task_view_task_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/task/view-task/view-task.component */ "./src/app/components/task/view-task/view-task.component.ts");
/* harmony import */ var ngx_bootstrap_modal__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-bootstrap/modal */ "./node_modules/ngx-bootstrap/modal/fesm5/ngx-bootstrap-modal.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};











var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"],
                _components_project_add_project_add_project_component__WEBPACK_IMPORTED_MODULE_5__["AddProjectComponent"],
                _components_task_add_task_add_task_component__WEBPACK_IMPORTED_MODULE_6__["AddTaskComponent"],
                _components_user_add_user_add_user_component__WEBPACK_IMPORTED_MODULE_7__["AddUserComponent"],
                _components_task_view_task_view_task_component__WEBPACK_IMPORTED_MODULE_8__["ViewTaskComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_4__["AppRoutingModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_10__["HttpClientModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                ngx_bootstrap_modal__WEBPACK_IMPORTED_MODULE_9__["ModalModule"].forRoot()
            ],
            providers: [],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/components/project/add-project/add-project.component.css":
/*!**************************************************************************!*\
  !*** ./src/app/components/project/add-project/add-project.component.css ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".button.buttonSearch {\r\n    background-color: rgb(106, 110, 106);\r\n    border: none;\r\n    color: white;\r\n    padding: 12px;\r\n    text-align: center;\r\n    text-decoration: none;\r\n    display: inline-block;\r\n    font-size: 16px;\r\n    margin: 1px 1px 1px 1px;\r\n    cursor: pointer;\r\n    border-radius: 50%;\r\n  }  \r\n  \r\n  .form-group.required .col-form-label:after {\r\n    content:\"*\";\r\n    color:red;\r\n  }  \r\n  \r\n  .pd-90{\r\n      padding-left: 92%;\r\n  }"

/***/ }),

/***/ "./src/app/components/project/add-project/add-project.component.html":
/*!***************************************************************************!*\
  !*** ./src/app/components/project/add-project/add-project.component.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"formContainer\">\n  <form class=\"needs-validation\" novalidate>\n    <div class=\"form-group row required\" style=\"margin-left:.1%\">\n      <div class=\"col-md-1\">\n        <label for=\"projectName\" class=\"col-sm-1 col-form-label col-form-label-lg\">Project:</label>\n      </div>\n      <div class=\"col-md-6\">\n        <input type=\"text\" name=\"projectName\" class=\"form-control\" id=\"projectName\" [(ngModel)]=\"project.projectName\">       \n      </div>     \n    </div>\n\n    <div class=\"form-group row\" style=\"margin-left:10%\">\n      <div class=\"col-md-2\">\n        <input class=\"form-check-input\" type=\"checkbox\" id=\"defaultCheck1\" (change)=\"onChecboxSelect($event)\">\n         Set Start and End Date\n      </div>\n      <div class=\"col-md-2\" style=\"margin-left: 1%\">\n        <input type=\"date\" id=\"startDate\" class=\"form-check-input\" name=\"startDate\" [(ngModel)]=\"project.startDate\"\n          disabled={{disabled}} />\n      </div>\n      <div class=\"col-md-2\" style=\"margin-left: 4%\">\n        <input type=\"date\" id=\"endDate\" class=\"form-check-input\" name=\"endDate\" [(ngModel)]=\"project.endDate\"\n          disabled={{disabled}} />\n      </div>\n    </div>\n\n    <div class=\"form-group row\" style=\"margin-left:.1%\">\n      <div class=\"col-md-1\">\n        <label for=\"priority\" class=\"col-sm-1 col-form-label col-form-label-lg\">Priority:</label>\n      </div>\n      <div class=\"col-md-6\">\n        <span class=\"font-weight-bold indigo-text mr-2 mt-1\">0</span>\n        <span class=\"font-weight-bold indigo-text ml-2 mt-1 pd-90\">30</span>\n        <input type=\"range\" (click)=\"onDrag($event)\" name=\"priority\" min=\"0\" max=\"30\" class=\"custom-range\"\n          [(ngModel)]=\"project.priority\">\n      </div>\n    </div>\n\n    <div class=\"form-group row required\" style=\"margin-left:.1%;height:50px\">\n      <div class=\"col-md-1\">\n        <label for=\"managerName\" class=\"col-sm-1 col-form-label col-form-label-lg\">Manager:</label>\n      </div>\n      <div class=\"col-md-5\">\n        <input type=\"text\" name=\"managerName\" class=\"form-control\" id=\"managerName\"\n          value=\"{{project.user.fullName}}\" readonly>\n      </div>\n      <div class=\"col-md-1\">\n        <button type=\"button\" id=\"search\" class=\"button buttonSearch\" (click)=\"openUserModal(template1)\">Serach</button>\n      </div>\n    </div>\n\n    <div class=\"form-group row\" style=\"margin-left:.1%\">\n      <div class=\"col-md-4\"></div>\n      <div class=\"col-md-1\" style=\"margin-left: 5px\">\n        <button type=\"button\" id=\"add\" class=\"btn btn-secondary btn-sm\" style=\"margin:10px;width:90px\"\n          (click)=\"saveOrUpdateProject()\" [disabled]=\"validateData()\">Add Project</button>\n      </div>\n      <div class=\"col-md-1\">\n        <button type=\"button\" id=\"reset\" class=\"btn btn-secondary btn-sm\" style=\"margin:10px;width:80px\"\n          (click)=\"reset()\">Reset</button>\n      </div>\n    </div>\n  </form>\n</div>\n\n<div class=\"col-md-7\" style=\"margin-left:.1%\">\n  <hr style=\"border:1px solid#7f797961\" />\n</div>\n\n<div class=\"row\" style=\"margin-left:.1%\">\n  <div class=\"col-md-1\">\n    <label for=\"Search\" class=\"col-sm-1 col-form-label col-form-label-lg\">Search</label>\n  </div>\n  <div class=\"col-md-6\">\n    <input type=\"text\" name=\"searchValue\" class=\"form-control\" id=\"searchValue\" [(ngModel)]=\"searchValue\">\n  </div>\n</div>\n\n<div class=\"row\" style=\"margin-left:5%\">\n  <div class=\"col-md-1\" style=\"margin-left: 2%\">\n    <label for=\"sortBy\" class=\"col-form-label-lg\">Sort By:</label>\n  </div>\n  <div class=\"col-md-1\">\n    <button type=\"button\" id=\"startDate\" class=\"btn btn-secondary btn-sm\" style=\"margin:10px;width:100px\"\n      (click)=\"sortByStartDate()\">Start Date</button>\n  </div>\n  <div class=\"col-md-1\">\n    <button type=\"button\" id=\"endDate\" class=\"btn btn-secondary btn-sm\" style=\"margin:10px;width:100px\"\n      (click)=\"sortByEndDate()\">End Date</button>\n  </div>\n  <div class=\"col-md-1\">\n    <button type=\"button\" id=\"priority\" class=\"btn btn-secondary btn-sm\" style=\"margin:10px;width:100px\"\n      (click)=\"sortByPriority()\">Priority</button>\n  </div>\n  <div class=\"col-md-1\">\n    <button type=\"button\" id=\"completed\" class=\"btn btn-secondary btn-sm\" style=\"margin:10px;width:100px\"\n      (click)=\"sortByCompletion()\">Completed</button>\n  </div>\n</div>\n\n<div *ngFor=\"let project of filteredData;let i=index\">\n  <div class=\"row\" style=\"margin-left:6%;\" id={{i}}>\n    <div class=\"col-md-4\" style=\"padding-right:.1%;background-color:hsla(0, 33%, 92%, 0.871)\">\n      <label for=\"project\" class=\"col-sm-1 col-form-label col-form-label-lg\">Project:</label>\n      <span style=\"margin: 20%\">{{project.projectName}}</span>\n      <div class=\"row\">\n        <div class=\"col-md-5\" style=\"margin:4%\">\n          <label for=\"project\" class=\"col-form-label-lg\">No Of Tasks:</label>\n          <span style=\"margin: 3%\">{{project.noOfTask}}</span>\n        </div>\n        <div class=\"col-md-5\" style=\"padding:4%\">\n          <label for=\"project\" class=\"col-sm-1 col-form-label col-form-label-lg\">Completed:</label>\n          <span style=\"margin:3%;padding-left:60%\">{{project.projectCompleted}}</span>\n        </div>\n      </div>\n      <div class=\"row\">\n        <div class=\"col-md-6\" style=\"margin-right:4%;margin-left:4%\">\n          <label for=\"startDate\" class=\"col-form-label-lg\">Start Date:</label>\n          <span style=\"margin-left:1%\">{{project.startDate}}</span>\n        </div>\n        <div class=\"col-md-5\" style=\"padding-left:.1%;padding-right:.5%;margin-right:.1%\">\n          <label for=\"endDate\" class=\"col-form-label-lg\">End Date:</label>\n          <span style=\"margin-left:1%\">{{project.endDate}}</span>\n        </div>\n      </div>\n    </div>\n    <div class=\"col-md-1\" style=\"background-color:hsla(3, 20%, 95%, 0.8705882352941177)\">\n      <label for=\"priority\" class=\"col-form-label-lg\">Priority</label>\n      <span style=\"margin: 30%\">{{project.priority}}</span>\n    </div>\n    <div class=\"col-md-2\" style=\"padding-top: 2%\">\n      <button type=\"button\" id=\"update\" class=\"btn btn-secondary btn-sm\" style=\"margin:10px;width:50%;height:30%\"\n        (click)=\"openProjectModal(template2,i)\" [disabled]=\"project.projectCompleted==='Y'\">Update</button>\n      <button type=\"button\" id=\"suspend\" class=\"btn btn-secondary btn-sm\" style=\"margin:10px;width:50%;height:30%\"\n        (click)=\"suspend(i)\" [disabled]=\"project.projectCompleted==='Y'\">Suspend</button>\n    </div>\n  </div>\n  <br />\n</div>\n\n<ng-template #template1>\n  <div class=\"modal-header\">\n    <h4 class=\"modal-title pull-left\">User</h4>\n    <button type=\"button\" class=\"close pull-right\" aria-label=\"Close\" (click)=\"closeUserModal()\">\n      <span aria-hidden=\"true\">&times;</span>\n    </button>\n  </div>\n  <div class=\"modal-body\" style=\"width:500px;height:500px\">\n    <div class=\"form-group row\">\n      <div class=\"col-md-2\">\n        <label for=\"Search\" class=\"col-form-label-lg\">Search</label>\n      </div>\n      <div class=\"col-md-6\">\n        <input type=\"text\" name=\"userSearchValue\" class=\"form-control\" [(ngModel)]=\"userSearchValue\" >\n      </div>\n    </div>\n    <div class=\"form-group row\">\n      <div class=\"col-md-6\">\n        <label for=\"name\" class=\"col-form-label-lg\">NAME</label>\n      </div>\n      <div class=\"col-md-3\">\n        <label for=\"empId\" class=\"col-form-label-lg\">EMP ID</label>\n      </div>\n    </div>\n    <div *ngFor=\"let user of userFilteredData;let i = index\">\n      <div class=\"form-group row\" id={{i}}>\n        <div class=\"col-md-6\">\n          <input type=\"text\" name=\"firstName\" class=\"form-control\" id=\"firstName\" readonly\n            value=\"{{user.firstName}} {{user.lastName}}\" />\n        </div>\n        <div class=\"col-md-3\">\n          <input type=\"text\" name=\"empId\" class=\"form-control\" id=\"empId\" disabled value={{user.empId}} />\n        </div>\n\n        <div class=\"col-md-3\" style=\"padding:1%\">\n          <button type=\"button\" id=\"select\" class=\"btn btn-secondary btn-sm\" (click)=\"selectUser(i)\">Select</button>\n        </div>\n      </div>\n    </div>\n  </div>\n</ng-template>\n\n<ng-template #template2>\n  <div class=\"modal-header\">\n    <h4 class=\"modal-title pull-left\">Update Project</h4>\n    <button type=\"button\" class=\"close pull-right\" aria-label=\"Close\" (click)=\"closeProjectModal()\">\n      <span aria-hidden=\"true\">&times;</span>\n    </button>\n  </div>\n  <div class=\"modal-body\" style=\"width:500px;height:500px\">    \n    <form class=\"needs-validation\" #addForm novalidate>\n      <div class=\"form-group required row\">\n        <label for=\"projectName2\" class=\"col-sm-3 col-form-label col-form-label-lg\">Project:</label>\n        <div class=\"col-md-9\">\n          <input type=\"text\" name=\"projectName2\" class=\"form-control\" id=\"projectName2\" [(ngModel)]=\"filteredData[index].projectName\">          \n        </div>\n      </div>\n\n      <div class=\"form-group row\">\n        <div class=\"col-md-3\" style=\"padding: 0%;margin: 0%\">\n          <input class=\"form-check-input\" type=\"checkbox\" id=\"defaultCheck1\" (change)=\"onChecboxSelect($event)\" style=\"margin-left: 3%\" >\n          <span style=\"margin-left: 15%\">Set Start and End Date</span> \n        </div>\n        <div class=\"col-md-4\" style=\"margin-left: 5%\" >\n          <input type=\"date\" id=\"startDate2\" class=\"form-check-input\" name=\"startDate2\" [(ngModel)]=\"filteredData[index].startDate\"\n            disabled=\"{{disabled}}\" />\n        </div>\n        <div class=\"col-md-1\" >\n          <input type=\"date\" id=\"endDate2\" class=\"form-check-input\" name=\"endDate2\" [(ngModel)]=\"filteredData[index].endDate\"\n               disabled=\"{{disabled}}\" />\n        </div>\n      </div>\n\n      <div class=\"form-group row required\">\n        <label for=\"priority2\" class=\"col-md-3 col-form-label col-form-label-lg\">Priority:</label>\n        <div class=\"col-sm-9\">\n          <span class=\"font-weight-bold indigo-text mr-2 mt-1\">0</span>\n          <span class=\"font-weight-bold indigo-text ml-0 mt-1 pd-90\">30</span>\n          <input type=\"range\" (click)=\"onDragUpdate($event,index)\" name=\"priority2\" min=\"0\" max=\"30\" class=\"custom-range\"\n            [(ngModel)]=\"filteredData[index].priority\" required>\n        </div>\n        <div class=\"invalid-feedback\">Priority is mandatory field</div>\n      </div>\n\n      <div class=\"form-group row required\" >\n        <div class=\"col-md-3\" style=\"padding-left: 0%\">\n          <label for=\"managerName\" class=\"col-sm-1 col-form-label col-form-label-lg\">Manager:</label>\n        </div>\n        <div class=\"col-md-6\" >\n          <input type=\"text\" name=\"managerName2\" class=\"form-control\" id=\"managerName2\"\n          value=\"{{project.user.firstName}} {{project.user.lastName}}\" readonly>\n        </div>\n        <div class=\"col-md-1\" style=\"margin-left: 5%\">\n          <button type=\"button\" id=\"search2\" class=\"button buttonSearch\" (click)=\"openUserModal(template1,index)\">Serach</button>\n        </div>\n      </div>\n\n      <div class=\"form-group row\">\n        <div class=\"col-sm-5\"></div>\n        <button type=\"button\" class=\"btn btn-secondary btn-sm\" style=\"margin:10px\"\n          [disabled]=\"validateData()\"\n          (click)=\"updateProject(index)\">Update</button>\n        <button type=\"button\" class=\"btn btn-secondary btn-sm\" style=\"margin:10px\" (click)=\"closeProjectModal()\">Close</button>\n        <div class=\"col-sm-2\"></div>\n      </div>\n    </form>\n  </div>\n</ng-template>"

/***/ }),

/***/ "./src/app/components/project/add-project/add-project.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/components/project/add-project/add-project.component.ts ***!
  \*************************************************************************/
/*! exports provided: AddProjectComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddProjectComponent", function() { return AddProjectComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_model_project__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/model/project */ "./src/app/model/project.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var src_app_model_user__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/model/user */ "./src/app/model/user.ts");
/* harmony import */ var ngx_bootstrap_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-bootstrap/modal */ "./node_modules/ngx-bootstrap/modal/fesm5/ngx-bootstrap-modal.js");
/* harmony import */ var src_app_services_project_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/project.service */ "./src/app/services/project.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var AddProjectComponent = /** @class */ (function () {
    function AddProjectComponent(modalService, projectService) {
        this.modalService = modalService;
        this.projectService = projectService;
        this._searchValue = "";
        this._userSearchValue = "";
        this.project = new src_app_model_project__WEBPACK_IMPORTED_MODULE_1__["Project"]();
        this.project.noOfTask = 1;
        this.project.user = new src_app_model_user__WEBPACK_IMPORTED_MODULE_3__["User"]();
    }
    Object.defineProperty(AddProjectComponent.prototype, "searchValue", {
        get: function () {
            return this._searchValue;
        },
        set: function (value) {
            this._searchValue = value;
            this.filteredData = this.searchValue ? this.performProjectFilter(this.searchValue) : this.projects;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AddProjectComponent.prototype, "userSearchValue", {
        get: function () {
            return this._userSearchValue;
        },
        set: function (value) {
            this._userSearchValue = value;
            this.userFilteredData = this.userSearchValue ? this.performUserFilter(this.userSearchValue) : this.users;
        },
        enumerable: true,
        configurable: true
    });
    AddProjectComponent.prototype.ngOnInit = function () {
        this.getTasks();
    };
    AddProjectComponent.prototype.getTasks = function () {
        var _this = this;
        var obs = this.projectService.getTasks();
        obs.subscribe(function (response) {
            _this.taskList = response ? response.data : null;
            _this.getProjects();
        }, function (error) { return _this.errorMsg = error; });
    };
    AddProjectComponent.prototype.getProjects = function () {
        var _this = this;
        var obs = this.projectService.getProjects();
        obs.subscribe(function (response) {
            _this.projects = response ? response.data : null;
            _this.filteredData = response ? response.data : null;
            _this.maipulateProjectData(_this.projects);
        }, function (error) { return _this.errorMsg = error; });
    };
    AddProjectComponent.prototype.getUsers = function () {
        var _this = this;
        var obs = this.projectService.getUsers();
        obs.subscribe(function (response) {
            _this.users = response ? response.data : null;
            _this.userFilteredData = response ? response.data : null;
        }, function (error) { return _this.errorMsg = error; });
    };
    AddProjectComponent.prototype.saveOrUpdateProject = function () {
        var _this = this;
        this.projectService.saveOrUpdateProject(this.project).subscribe(function (response) {
            _this.reset();
        }, function (error) { return _this.errorMsg = error; });
    };
    AddProjectComponent.prototype.updateProject = function (i) {
        var _this = this;
        this.projectService.saveOrUpdateProject(this.filteredData[i]).subscribe(function (response) {
            _this.closeProjectModal();
        }, function (error) { return _this.errorMsg = error; });
    };
    AddProjectComponent.prototype.suspend = function (i) {
        var _this = this;
        this.filteredData[i].projectCompleted = "Y";
        this.projectService.saveOrUpdateProject(this.filteredData[i]).subscribe(function (response) {
        }, function (error) { return _this.errorMsg = error; });
    };
    AddProjectComponent.prototype.performProjectFilter = function (filterValue) {
        filterValue = filterValue.toLocaleLowerCase();
        return this.projects.filter(function (project) { return project.projectName.toLocaleLowerCase().indexOf(filterValue) !== -1; });
    };
    AddProjectComponent.prototype.performUserFilter = function (filterValue) {
        filterValue = filterValue.toLocaleLowerCase();
        return this.users.filter(function (user) { return user.firstName.toLocaleLowerCase().indexOf(filterValue) !== -1; });
    };
    AddProjectComponent.prototype.onChecboxSelect = function (event) {
        if (event.target.checked) {
            this.currentDate = new Date();
            this.nextDate = new Date();
            this.nextDate.setDate(this.currentDate.getDate() + 1);
            this.project.startDate = Object(_angular_common__WEBPACK_IMPORTED_MODULE_2__["formatDate"])(this.currentDate, 'yyyy-MM-dd', 'en');
            this.project.endDate = Object(_angular_common__WEBPACK_IMPORTED_MODULE_2__["formatDate"])(this.nextDate, 'yyyy-MM-dd', 'en');
            this.disabled = false;
        }
        else if (!event.target.checked) {
            this.project.startDate = "";
            this.project.endDate = "";
            this.disabled = true;
        }
    };
    AddProjectComponent.prototype.onDrag = function (event) {
        this.project.priority = event.target.value;
    };
    AddProjectComponent.prototype.onDragUpdate = function (event, i) {
        this.filteredData[i].priority = event.target.value;
    };
    AddProjectComponent.prototype.sortByStartDate = function () {
        this.filteredData.sort(function (a, b) {
            var date1 = new Date(a.startDate);
            var date2 = new Date(b.startDate);
            if (date1 > date2)
                return -1;
            if (date1 < date2)
                return 1;
            return 0;
        });
    };
    AddProjectComponent.prototype.sortByEndDate = function () {
        this.filteredData.sort(function (a, b) {
            var date1 = new Date(a.endDate);
            var date2 = new Date(b.endDate);
            if (date1 > date2)
                return -1;
            if (date1 < date2)
                return 1;
            return 0;
        });
    };
    AddProjectComponent.prototype.sortByPriority = function () {
        this.filteredData.sort(function (a, b) {
            var value1 = a.priority;
            var value2 = b.priority;
            return value2 - value1;
        });
    };
    AddProjectComponent.prototype.sortByCompletion = function () {
        this.filteredData.sort(function (a, b) {
            var value1 = a.projectCompleted.toLocaleLowerCase();
            var value2 = b.projectCompleted.toLocaleLowerCase();
            if (value1 < value2)
                return -1;
            if (value1 > value2)
                return 1;
            return 0;
        });
    };
    AddProjectComponent.prototype.openUserModal = function (template, i) {
        this.getUsers();
        if (this.filteredData[i]) {
            this.project = this.filteredData[i];
        }
        this.userModalRef = this.modalService.show(template);
    };
    AddProjectComponent.prototype.openProjectModal = function (template, i) {
        this.index = i;
        this.project = this.filteredData[i];
        this.projectModalRef = this.modalService.show(template);
    };
    AddProjectComponent.prototype.closeUserModal = function () {
        this.userModalRef.hide();
    };
    AddProjectComponent.prototype.closeProjectModal = function () {
        this.reset();
        this.getProjects();
        this.projectModalRef.hide();
    };
    AddProjectComponent.prototype.selectUser = function (i) {
        var user = this.userFilteredData[i];
        this.project.user = user;
        this.project.user.fullName = user.firstName + " " + user.lastName;
        this.userModalRef.hide();
    };
    AddProjectComponent.prototype.reset = function () {
        this.project.endDate = '';
        this.project.projectId = '';
        this.project.startDate = '';
        this.project.priority = 0;
        this.project.projectName = '';
        this.project.user = new src_app_model_user__WEBPACK_IMPORTED_MODULE_3__["User"]();
        this.getProjects();
    };
    AddProjectComponent.prototype.validateData = function (project) {
        var startDateStr = this.project.startDate;
        var endDateStr = this.project.endDate;
        var startDate = new Date(startDateStr);
        var endDate = new Date(endDateStr);
        var flag = true;
        if (startDate && endDate && this.project.user.firstName && this.project.user.lastName && this.project.projectName && endDate.getTime() >= startDate.getTime()) {
            flag = false;
        }
        return flag;
    };
    AddProjectComponent.prototype.maipulateProjectData = function (projects) {
        var _this = this;
        var projectsWithTaskNo = projects.map(function (project) {
            var filteredTasks = _this.taskList.filter(function (task) { return task.project.projectId === project.projectId; });
            project.noOfTask = filteredTasks ? filteredTasks.length : 0;
            return project;
        });
        this.filteredData = projectsWithTaskNo;
    };
    AddProjectComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-add-project',
            template: __webpack_require__(/*! ./add-project.component.html */ "./src/app/components/project/add-project/add-project.component.html"),
            styles: [__webpack_require__(/*! ./add-project.component.css */ "./src/app/components/project/add-project/add-project.component.css")]
        }),
        __metadata("design:paramtypes", [ngx_bootstrap_modal__WEBPACK_IMPORTED_MODULE_4__["BsModalService"], src_app_services_project_service__WEBPACK_IMPORTED_MODULE_5__["ProjectService"]])
    ], AddProjectComponent);
    return AddProjectComponent;
}());



/***/ }),

/***/ "./src/app/components/task/add-task/add-task.component.css":
/*!*****************************************************************!*\
  !*** ./src/app/components/task/add-task/add-task.component.css ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".button.buttonSearch {\r\n    background-color: rgb(106, 110, 106); /* Green */\r\n    border: none;\r\n    color: white;\r\n    padding: 12px;\r\n    text-align: center;\r\n    text-decoration: none;\r\n    display: inline-block;\r\n    font-size: 16px;\r\n    margin: 1px 1px 1px 1px;\r\n    cursor: pointer;\r\n    border-radius: 50%;\r\n  }\r\n  \r\n  input[type=\"button\"]:disabled {\r\n    background-color:#b1b8b7;\r\n  }\r\n  \r\n  .form-group.required .col-form-label:after {\r\n    content:\"*\";\r\n    color:red;\r\n  }\r\n  \r\n  .pd-90{\r\n      padding-left: 92%;\r\n  }"

/***/ }),

/***/ "./src/app/components/task/add-task/add-task.component.html":
/*!******************************************************************!*\
  !*** ./src/app/components/task/add-task/add-task.component.html ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<form class=\"needs-validation\" novalidate>\n\n  <div class=\"form-group row required\" style=\"margin-left:1%\">\n    <div class=\"col-md-1\">\n      <label for=\"projectName\" class=\"col-sm-2 col-form-label col-form-label-lg\"\n        style=\"padding-left:.1%\">Project:</label>\n    </div>\n    <div class=\"col-md-4\">\n      <input type=\"text\" class=\"form-control\" id=\"projectName\" name=\"projectName\" [(ngModel)]=\"task.project.projectName\"\n        readonly>\n    </div>\n    <div class=\"col-md-2\">\n      <button type=\"button\" id=\"search\" class=\"button buttonSearch\"\n        (click)=\"openProjectModal(template1)\">Serach</button>\n    </div>\n  </div>\n\n  <div class=\"form-group row required\" style=\"margin-left:.1%\">\n    <div class=\"col-md-1\">\n      <label for=\"task\" class=\"col-sm-4 col-form-label col-form-label-lg\">Task:</label>\n    </div>\n    <div class=\"col-md-5\">\n      <input type=\"text\" name=\"task\" class=\"form-control\" id=\"task\" [(ngModel)]=\"task.taskName\"\n        style=\"margin-left: 2%\">\n    </div>\n  </div>\n\n  <div class=\"form-group row\" style=\"margin-left:1%\">\n    <div class=\"col-md-1\" style=\"margin-left:1.5%\">\n    </div>\n    <div class=\"col-md-4\">\n      <input class=\"form-check-input\" type=\"checkbox\" id=\"defaultCheck1\" (change)=\"onChecboxSelect($event)\" checked>\n      <span>Parent Task</span>\n    </div>\n  </div>\n\n  <div class=\"form-group row\" style=\"margin-left:.1%\">\n    <div class=\"col-md-1\">\n      <label for=\"priority\" class=\"col-sm-2 col-form-label col-form-label-lg\">Priority:</label>\n    </div>\n    <div class=\"col-md-5\" style=\"margin-left: 1%\">\n      <span class=\"font-weight-bold indigo-text mr-2 mt-1\">0</span>\n      <span class=\"font-weight-bold indigo-text ml-2 mt-1 pd-90\">30</span>\n      <input type=\"range\" (click)=\"onDrag($event)\" name=\"priority\" min=\"0\" max=\"30\" class=\"custom-range\"\n        [(ngModel)]=\"task.priority\">\n    </div>\n  </div>\n\n  <div class=\"form-group row required\" style=\"margin-left:.1%\">\n    <div class=\"col-md-1\">\n      <label for=\"parentTask\" class=\"col-sm-2 col-form-label col-form-label-lg\" style=\"white-space:nowrap\">Parent\n        Task:</label>\n    </div>\n    <div class=\"col-md-4\" style=\"margin-left:1%\">\n      <input type=\"text\" class=\"form-control\" id=\"parentTask\" name=\"parentTask\" [(ngModel)]=\"task.parentTask.parentTaskName\"\n        readonly>\n    </div>\n    <div class=\"col-md-2\">\n      <button type=\"button\" id=\"search\" class=\"button buttonSearch\" (click)=\"openParentTaskModal(template2)\"\n        [disabled]=\"task.parentTask.parentTaskDisabled\">Serach</button>\n    </div>\n  </div>\n\n  <div class=\"form-group row required\" style=\"margin-left:.1%\">\n    <div class=\"col-md-1\">\n      <label for=\"startDate\" class=\"col-sm-2 col-form-label col-form-label-lg\" style=\"white-space:nowrap\">Start\n        Date:</label>\n    </div>\n    <div class=\"col-md-2\" style=\"margin-left:1%\">\n      <input type=\"date\" name=\"startDate\" class=\"form-control\" placeholder=\"DD/MM/YYYY\" id=\"startDate\"\n        [(ngModel)]=\"task.startDate\">\n    </div>\n    <div class=\"col-md-1\">\n      <label for=\"endDate\" class=\"col-sm-2 col-form-label col-form-label-lg\" style=\"white-space:nowrap\">End\n        Date:</label>\n    </div>\n    <div class=\"col-md-2\">\n      <input type=\"date\" name=\"endDate\" class=\"form-control\" placeholder=\"DD/MM/YYYY\" id=\"endDate\"\n        [(ngModel)]=\"task.endDate\">\n    </div>\n  </div>\n\n  <div class=\"form-group row required\" style=\"margin-left:.1%\">\n    <div class=\"col-md-1\">\n      <label for=\"user\" class=\"col-sm-2 col-form-label col-form-label-lg\">User:</label>\n    </div>\n    <div class=\"col-md-4\" style=\"margin-left:1%\">\n      <input type=\"text\" class=\"form-control\" id=\"user\" name=\"user\" value=\"{{task.user.fullName}}\" readonly>\n    </div>\n    <div class=\"col-md-4\">\n      <button type=\"button\" id=\"search\" class=\"button buttonSearch\" (click)=\"openUserModal(template3)\">Serach</button>\n    </div>\n  </div>\n\n  <div class=\"form-group row\" style=\"margin-left:1%\">\n    <div class=\"col-md-3\">\n    </div>\n    <div class=\"col-md-2\" style=\"padding-left: 10%\">\n      <button type=\"button\" id=\"add\" class=\"btn btn-secondary btn-sm\"\n        [disabled]=\"!(task.taskName && task.startDate && task.endDate && task.project.projectName && task.user.fullName && task.parentTask.parentTaskName && validateDate())\"\n        (click)=\"saveOrUpdateTask()\">Add Task</button>\n    </div>\n    <div class=\"col-md-3\">\n      <button type=\"button\" id=\"reset\" class=\"btn btn-secondary btn-sm\" style=\"margin:10px\" (click)=\"reset()\"\n        style=\"padding-top:0%;width:25%\">Reset</button>\n    </div>\n\n  </div>\n\n</form>\n\n<ng-template #template1>\n  <div class=\"modal-header\">\n    <h4 class=\"modal-title pull-left\">Project</h4>\n    <button type=\"button\" class=\"close pull-right\" aria-label=\"Close\" (click)=\"closeProjectModal()\">\n      <span aria-hidden=\"true\">&times;</span>\n    </button>\n  </div>\n  <div class=\"modal-body\" style=\"width:500px;height:500px\">\n    <div class=\"row\">\n      <div class=\"col-md-2\">\n        <label for=\"Search\" class=\"col-form-label-lg\" style=\"margin-left: 25%\">Search</label>\n      </div>\n      <div class=\"col-md-6\">\n        <input type=\"text\" name=\"projectSearchValue\" class=\"form-control\" [(ngModel)]=\"projectSearchValue\">\n      </div>\n    </div>\n    <div class=\"row\">\n      <div class=\"col-md-3\">\n        <label for=\"projectName2\" class=\"col-sm-3 col-form-label col-form-label-lg\">Project</label>\n      </div>\n      <div class=\"col-md-3\" style=\"padding-right:20px;padding-left:5px\" >\n        <label for=\"projectName2\" class=\"col-sm-3 col-form-label col-form-label-lg\" style=\"white-space:nowrap;padding-left:2px\">Start\n          Date</label>\n      </div>\n      <div class=\"col-md-3\">\n        <label for=\"projectName2\" class=\"col-sm-3 col-form-label col-form-label-lg\" style=\"white-space:nowrap;padding-left:2px\">End\n          Date</label>\n      </div>\n\n      <div *ngFor=\"let project of filteredProjects;let i = index\">\n        <div class=\"row\" id={{i}}>\n          <div class=\"col-md-3\">\n            <input type=\"text\" name=\"projectName\" class=\"form-control\" id=\"projectName\" readonly\n              value=\"{{project.projectName}}\" style=\"margin-left:20%\">\n          </div>\n          <div class=\"col-md-3\" style=\"margin-left:0%\">\n            <input type=\"text\" name=\"startDate\" class=\"form-control\" id=\"startDate\" readonly\n              value=\"{{project.startDate}}\" style=\"padding-right:3px;\">\n          </div>\n          <div class=\"col-md-3\">\n            <input type=\"text\" name=\"endDate\" class=\"form-control\" id=\"endDate\" readonly\n              value=\"{{project.endDate}}\" style=\"padding-right:3px;padding-left:2px\">\n          </div>\n          <div class=\"col-md-3\" style=\"padding:1%\">\n            <button type=\"button\" id=\"select\" class=\"btn btn-secondary btn-sm\" (click)=\"selectProject(i)\"\n              style=\"margin-left:20%\">Select</button>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</ng-template>\n\n<ng-template #template2>\n  <div class=\"modal-header\">\n    <h4 class=\"modal-title pull-left\">Parent Task</h4>\n    <button type=\"button\" class=\"close pull-right\" aria-label=\"Close\" (click)=\"closeParentTaskModal()\">\n      <span aria-hidden=\"true\">&times;</span>\n    </button>\n  </div>\n  <div class=\"modal-body\" style=\"width:500px;height:500px\">\n    <div class=\"row\">\n      <div class=\"col-md-2\">\n        <label for=\"Search\" class=\"col-form-label-lg\" style=\"margin-left: 25%\">Search</label>\n      </div>\n      <div class=\"col-md-6\">\n        <input type=\"text\" name=\"parentTaskSearchValue\" class=\"form-control\" [(ngModel)]=\"parentTaskSearchValue\">\n      </div>\n    </div>\n    <div class=\"row\">\n      <div class=\"col-md-4\">\n        <label for=\"parentTaskName\" class=\"col-sm-3 col-form-label col-form-label-lg\" style=\"white-space:nowrap\">Parent Task</label>\n      </div>\n      \n      <div class=\"col-md-4\">\n        <label for=\"parentTaskId\" class=\"col-sm-4 col-form-label col-form-label-lg\" style=\"white-space:nowrap;padding-left:5%\">Parent Task ID\n          </label>\n      </div>\n\n      <div *ngFor=\"let parentTask of filteredParentTasks;let i = index\">\n        <div class=\"row\" id={{i}}>\n          <div class=\"col-md-4\">\n            <input type=\"text\" name=\"parentTaskName\" class=\"form-control\" id=\"parentTaskName\" disabled=true\n              value=\"{{parentTask.parentTaskName}}\" style=\"margin-left:20%\">\n          </div>\n          <div class=\"col-md-3\">\n            <input type=\"text\" name=\"parentId\" class=\"form-control\" id=\"parentId\" disabled=true\n              value=\"{{parentTask.parentTaskId}}\" style=\"margin-left:20%\">\n          </div>          \n          <div class=\"col-md-3\" style=\"padding:1%\">\n            <button type=\"button\" id=\"select\" class=\"btn btn-secondary btn-sm\" (click)=\"selectParentTask(i)\"\n              style=\"margin-left:20%\">Select</button>\n          </div>\n        </div>\n      </div>\n\n    </div>\n  </div>\n</ng-template>\n\n<ng-template #template3>\n  <div class=\"modal-header\">\n    <h4 class=\"modal-title pull-left\">User</h4>\n    <button type=\"button\" class=\"close pull-right\" aria-label=\"Close\" (click)=\"closeUserModal()\">\n      <span aria-hidden=\"true\">&times;</span>\n    </button>\n  </div>\n  <div class=\"modal-body\" style=\"width:500px;height:500px\">\n    <div class=\"form-group row\">\n      <div class=\"col-md-2\">\n        <label for=\"Search\" class=\"col-form-label-lg\">Search</label>\n      </div>\n      <div class=\"col-md-6\">\n        <input type=\"text\" name=\"userSearchValue\" class=\"form-control\" [(ngModel)]=\"userSearchValue\" />\n      </div>\n    </div>\n    <div class=\"form-group row\">\n      <div class=\"col-md-6\">\n        <label for=\"name\" class=\"col-form-label-lg\">NAME</label>\n      </div>\n      <div class=\"col-md-3\">\n        <label for=\"empId\" class=\"col-form-label-lg\">EMP ID</label>\n      </div>\n    </div>\n    <div *ngFor=\"let user of filteredUsers;let i = index\">\n      <div class=\"form-group row\" id={{i}}>\n        <div class=\"col-md-6\">\n          <input type=\"text\" name=\"firstName\" class=\"form-control\" id=\"firstName\" disabled=true\n            value=\"{{user.firstName}} {{user.lastName}}\" />\n        </div>\n        <div class=\"col-md-3\">\n          <input type=\"text\" name=\"empId\" class=\"form-control\" id=\"empId\" disabled=true value={{user.empId}} />\n        </div>\n\n        <div class=\"col-md-3\" style=\"padding:1%\">\n          <button type=\"button\" id=\"select\" class=\"btn btn-secondary btn-sm\" (click)=\"selectUser(i)\">Select</button>\n        </div>\n      </div>\n    </div>\n  </div>\n</ng-template>"

/***/ }),

/***/ "./src/app/components/task/add-task/add-task.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/components/task/add-task/add-task.component.ts ***!
  \****************************************************************/
/*! exports provided: AddTaskComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddTaskComponent", function() { return AddTaskComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_model_pm_task__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/model/pm-task */ "./src/app/model/pm-task.ts");
/* harmony import */ var src_app_model_project__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/model/project */ "./src/app/model/project.ts");
/* harmony import */ var src_app_model_pm_parent_task__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/model/pm-parent-task */ "./src/app/model/pm-parent-task.ts");
/* harmony import */ var src_app_model_user__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/model/user */ "./src/app/model/user.ts");
/* harmony import */ var src_app_services_project_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/project.service */ "./src/app/services/project.service.ts");
/* harmony import */ var ngx_bootstrap_modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-bootstrap/modal */ "./node_modules/ngx-bootstrap/modal/fesm5/ngx-bootstrap-modal.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var AddTaskComponent = /** @class */ (function () {
    function AddTaskComponent(modalService, projectService) {
        this.modalService = modalService;
        this.projectService = projectService;
        this._projectSearchValue = "";
        this._parentTaskSearchValue = "";
        this._userSearchValue = "";
        this.task = new src_app_model_pm_task__WEBPACK_IMPORTED_MODULE_1__["PmTask"]();
        this.task.project = new src_app_model_project__WEBPACK_IMPORTED_MODULE_2__["Project"]();
        this.task.priority = 0;
        this.task.parentTask = new src_app_model_pm_parent_task__WEBPACK_IMPORTED_MODULE_3__["PmParentTask"]();
        this.task.user = new src_app_model_user__WEBPACK_IMPORTED_MODULE_4__["User"]();
    }
    Object.defineProperty(AddTaskComponent.prototype, "projectSearchValue", {
        get: function () {
            return this._projectSearchValue;
        },
        set: function (value) {
            this._projectSearchValue = value;
            this.filteredProjects = this.projectSearchValue ? this.performProjectFilter(this.projectSearchValue) : this.projects;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AddTaskComponent.prototype, "parentTaskSearchValue", {
        get: function () {
            return this._parentTaskSearchValue;
        },
        set: function (value) {
            this._parentTaskSearchValue = value;
            this.filteredParentTasks = this.parentTaskSearchValue ? this.performParentTaskFilter(this.parentTaskSearchValue) : this.parentTasks;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AddTaskComponent.prototype, "userSearchValue", {
        get: function () {
            return this._userSearchValue;
        },
        set: function (value) {
            this._userSearchValue = value;
            this.filteredUsers = this.userSearchValue ? this.performUserFilter(this.userSearchValue) : this.users;
        },
        enumerable: true,
        configurable: true
    });
    AddTaskComponent.prototype.ngOnInit = function () {
    };
    AddTaskComponent.prototype.saveOrUpdateTask = function () {
        var _this = this;
        this.projectService.saveOrUpdateTask(this.task).subscribe(function (response) {
            _this.reset();
        }, function (error) { return _this.errorMsg = error; });
    };
    AddTaskComponent.prototype.getProjects = function () {
        var _this = this;
        var obs = this.projectService.getProjects();
        obs.subscribe(function (response) {
            _this.projects = response ? response.data : null;
            _this.filteredProjects = response ? response.data : null;
        }, function (error) { return _this.errorMsg = error; });
    };
    AddTaskComponent.prototype.getParentTasks = function () {
        var _this = this;
        var obs = this.projectService.getParentTasks();
        obs.subscribe(function (response) {
            _this.parentTasks = response ? response.data : null;
            _this.filteredParentTasks = response ? response.data : null;
        }, function (error) { return _this.errorMsg = error; });
    };
    AddTaskComponent.prototype.getUsers = function () {
        var _this = this;
        var obs = this.projectService.getUsers();
        obs.subscribe(function (response) {
            _this.users = response ? response.data : null;
            _this.filteredUsers = response ? response.data : null;
        }, function (error) { return _this.errorMsg = error; });
    };
    AddTaskComponent.prototype.performProjectFilter = function (filterValue) {
        filterValue = filterValue.toLocaleLowerCase();
        return this.projects.filter(function (project) { return project.projectName.toLocaleLowerCase().indexOf(filterValue) !== -1; });
    };
    AddTaskComponent.prototype.performParentTaskFilter = function (filterValue) {
        filterValue = filterValue.toLocaleLowerCase();
        return this.parentTasks.filter(function (parentTask) { return parentTask.parentTaskName.toLocaleLowerCase().indexOf(filterValue) !== -1; });
    };
    AddTaskComponent.prototype.performUserFilter = function (filterValue) {
        filterValue = filterValue.toLocaleLowerCase();
        return this.users.filter(function (user) { return user.firstName.toLocaleLowerCase().indexOf(filterValue) !== -1; });
    };
    AddTaskComponent.prototype.openProjectModal = function (template) {
        this.getProjects();
        this.projectModalRef = this.modalService.show(template);
    };
    AddTaskComponent.prototype.closeProjectModal = function () {
        this.projectModalRef.hide();
    };
    AddTaskComponent.prototype.selectProject = function (i) {
        this.task.project = this.filteredProjects[i];
        this.closeProjectModal();
    };
    AddTaskComponent.prototype.openParentTaskModal = function (template) {
        this.getParentTasks();
        this.parentTaskModalRef = this.modalService.show(template);
    };
    AddTaskComponent.prototype.closeParentTaskModal = function () {
        this.parentTaskModalRef.hide();
    };
    AddTaskComponent.prototype.selectParentTask = function (i) {
        this.task.parentTask = this.filteredParentTasks[i];
        this.closeParentTaskModal();
    };
    AddTaskComponent.prototype.openUserModal = function (template) {
        this.getUsers();
        this.userModalRef = this.modalService.show(template);
    };
    AddTaskComponent.prototype.closeUserModal = function () {
        this.userModalRef.hide();
    };
    AddTaskComponent.prototype.selectUser = function (i) {
        var user = this.filteredUsers[i];
        this.task.user = user;
        this.task.user.fullName = user.firstName + " " + user.lastName;
        this.closeUserModal();
    };
    AddTaskComponent.prototype.onChecboxSelect = function (event) {
        this.task.parentTask.parentTaskDisabled = false;
        if (!event.target.checked) {
            this.task.parentTask.parentTaskDisabled = true;
            this.task.parentTask.parentTaskName = "";
        }
    };
    AddTaskComponent.prototype.onDrag = function (event) {
        this.task.priority = event.target.value;
    };
    AddTaskComponent.prototype.reset = function () {
        this.task.project.projectName = "";
        this.task.taskName = "";
        this.task.user.fullName = "";
        this.task.startDate = "";
        this.task.endDate = "";
        this.task.parentTask.parentTaskName = "";
    };
    AddTaskComponent.prototype.validateDate = function () {
        var startDateStr = this.task.startDate;
        var endDateStr = this.task.endDate;
        var startDate = new Date(startDateStr);
        var endDate = new Date(endDateStr);
        var flag = false;
        if (endDate.getTime() >= startDate.getTime()) {
            flag = true;
        }
        return flag;
    };
    AddTaskComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-add-task',
            template: __webpack_require__(/*! ./add-task.component.html */ "./src/app/components/task/add-task/add-task.component.html"),
            styles: [__webpack_require__(/*! ./add-task.component.css */ "./src/app/components/task/add-task/add-task.component.css")]
        }),
        __metadata("design:paramtypes", [ngx_bootstrap_modal__WEBPACK_IMPORTED_MODULE_6__["BsModalService"], src_app_services_project_service__WEBPACK_IMPORTED_MODULE_5__["ProjectService"]])
    ], AddTaskComponent);
    return AddTaskComponent;
}());



/***/ }),

/***/ "./src/app/components/task/view-task/view-task.component.css":
/*!*******************************************************************!*\
  !*** ./src/app/components/task/view-task/view-task.component.css ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".form-group.required .col-form-label:after {\r\n    content:\"*\";\r\n    color:red;\r\n  }\r\n\r\n  .pd-90{\r\n      padding-left: 92%;\r\n  }\r\n\r\n  .button.buttonSearch {\r\n    background-color: rgb(106, 110, 106); /* Green */\r\n    border: none;\r\n    color: white;\r\n    padding: 12px;\r\n    text-align: center;\r\n    text-decoration: none;\r\n    display: inline-block;\r\n    font-size: 16px;\r\n    margin: 1px 1px 1px 1px;\r\n    cursor: pointer;\r\n    border-radius: 50%;\r\n  }"

/***/ }),

/***/ "./src/app/components/task/view-task/view-task.component.html":
/*!********************************************************************!*\
  !*** ./src/app/components/task/view-task/view-task.component.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\n  <div class=\"col-md-1\" style=\"margin-left:1%\">\n    <label for=\"taskName\" class=\"col-sm-2 col-form-label-lg\">Project:</label>\n  </div>\n  <span>\n    <input type=\"text\" class=\"form-control\" id=\"projectId\" [(ngModel)]=\"projectId\" readonly>\n  </span>\n  <div class=\"col-md-2\">\n    <button type=\"button\" id=\"search\" class=\"button buttonSearch\" (click)=\"openProjectModal(template3)\">Serach</button>\n    \n    <button type=\"button\" id=\"allTask\" class=\"btn btn-secondary btn-sm\" (click)=\"reset()\" style=\"margin-left:5%\">All Task</button>\n  </div>\n\n  <div class=\"col-md-6\">\n    <span>Sort By:</span>\n    <span>\n      <button type=\"button\" id=\"startDate\" class=\"btn btn-secondary btn-sm\" (click)=\"sortByStartDate()\"\n        style=\"margin-left:2%\">Start Date</button>\n    </span>\n    <span>\n      <button type=\"button\" id=\"endDate\" class=\"btn btn-secondary btn-sm\" (click)=\"sortByEndDate()\"\n        style=\"margin-left:1.5%\">End Date</button>\n    </span>\n    <span>\n      <button type=\"button\" id=\"priority\" class=\"btn btn-secondary btn-sm\" style=\"margin-left:1%\"\n        (click)=\"sortByPriority()\" style=\"margin-left:1.5%\">Priority</button>\n    </span>\n    <span>\n      <button type=\"button\" id=\"completed\" class=\"btn btn-secondary btn-sm\" style=\"margin-left:1.5%\"\n        (click)=\"sortByCompletion()\">Completed</button>\n    </span>\n  </div>\n</div>\n\n\n<div class=\"col-md-8\" style=\"margin-left:2%\">\n  <hr style=\"border-top: dotted 1px;\" />\n</div>\n\n<div *ngFor=\"let task of filteredTasks;let i = index\">\n  <div class=\"row\" id=\"{{i}}\">\n    <div class=\"col-md-2\" style=\"margin-left:1%\">\n      <label for=\"taskName\" class=\"col-sm-2 col-form-label-lg\">Task</label>\n      <div class=\"card\">\n        <div class=\"card-body\" id=\"taskName\">{{task.taskName}}</div>\n      </div>\n    </div>\n    <div class=\"col-md-2\">\n      <label for=\"parentTask\" class=\"col-sm-2 col-form-label-lg\">Parent</label>\n      <div class=\"card\">\n        <div class=\"card-body\" id=\"parentTask\">{{task.parentTask.parentTaskName}}</div>\n      </div>\n    </div>\n    <div class=\"col-sm-1\">\n      <label for=\"priority\" class=\"col-sm-2 col-form-label-lg\">Priority</label>\n      <div class=\"card\">\n        <div class=\"card-body\" id=\"priority\" style=\"padding-left:50%\">{{task.priority}}</div>\n      </div>\n    </div>\n    <div class=\"col-md-1\">\n      <label for=\"startDat\" class=\"col-sm-2 col-form-label-lg\" style=\"white-space:nowrap\">Start</label>\n      <div class=\"card\">\n        <div class=\"card-body\" id=\"startDat\" style=\"white-space:nowrap;padding-left:1%\">{{task.startDate}}</div>\n      </div>\n    </div>\n    <div class=\"col-md-1\">\n      <label for=\"endDat\" class=\"col-sm-2 col-form-label-lg\" style=\"white-space:nowrap\">End</label>\n      <div class=\"card\">\n        <div class=\"card-body\" id=\"endDat\" style=\"white-space:nowrap;padding-left:1%\">{{task.endDate}}</div>\n      </div>\n    </div>\n    <div class=\"col-sm-2\" style=\"padding-top:5%;padding-left:0%\">\n      <span style=\"margin-left:0%\">\n        <button type=\"button\" [disabled]=\"task.taskCompleted==='Y'\" class=\"btn btn-secondary btn-sm\"\n          (click)=\"openModal(template,i)\" style=\"width:30%\">Edit</button>\n      </span>\n      <span style=\"margin-left:2%\">\n        <button type=\"button\" [disabled]=\"task.taskCompleted==='Y'\" class=\"btn btn-secondary btn-sm\"\n          (click)=\"endTask(i)\">End Task</button>\n      </span>\n    </div>\n  </div>\n</div>\n\n<ng-template #template>\n  <div class=\"modal-header\">\n    <h4 class=\"modal-title pull-left\">Update Task</h4>\n    <button type=\"button\" class=\"close pull-right\" aria-label=\"Close\" (click)=\"closeModal()\">\n      <span aria-hidden=\"true\">&times;</span>\n    </button>\n  </div>\n  <div class=\"modal-body\">\n    <form class=\"needs-validation\" #addForm novalidate>\n      <div class=\"form-group row required\" style=\"margin-left:1.5%\">\n        <label for=\"taskName2\" class=\"col-sm-2 col-form-label\">Task:</label>\n        <div class=\"col-md-6\">\n          <input type=\"text\" name=\"taskName2\" class=\"form-control\" id=\"taskName2\"\n            [(ngModel)]=\"filteredTasks[index].taskName\">\n        </div>\n      </div>\n\n      <div class=\"form-group row\" style=\"margin-left:1.5%\">\n        <label for=\"priority2\" class=\"col-sm-2 col-form-label\">Priority:</label>\n        <div class=\"col-md-6\">\n          <span class=\"font-weight-bold indigo-text mr-2 mt-1\">0</span>\n          <span class=\"font-weight-bold indigo-text ml-2 mt-1 pd-90\">30</span>\n          <input type=\"range\" (click)=\"onKey($event,index)\" name=\"priority2\" min=\"0\" max=\"30\" class=\"custom-range\"\n            style=\"margin-left:2%\" [(ngModel)]=\"filteredTasks[index].priority\">\n        </div>\n      </div>\n\n      <div class=\"form-group row required\" style=\"margin-left:1.3%\">\n        <label for=\"parentTask2\" class=\"col-sm-2 col-form-label\" style=\"white-space:nowrap\">Parent Task:</label>\n        <div class=\"col-md-6\">\n          <input type=\"text\" name=\"parentTask2\" class=\"form-control\" id=\"parentTask2\" style=\"margin-left:2%\"\n            [(ngModel)]=\"filteredTasks[index].parentTask.parentTaskName\" readonly>\n        </div>\n        <div class=\"col-md-2\">\n          <button type=\"button\" id=\"search\" class=\"button buttonSearch\"\n            (click)=\"openParentTaskModal(template2)\">Serach</button>\n        </div>\n      </div>\n\n      <div class=\"form-group required row\" style=\"margin-left:1.5%\">\n        <label for=\"startDate2\" class=\"col-sm-2 col-form-label\" style=\"white-space:nowrap\">Start Date:</label>\n        <div class=\"col-md-6\">\n          <input type=\"date\" name=\"startDate\" class=\"form-control\" placeholder=\"DD/MM/YYYY\" id=\"startDate2\"\n            [(ngModel)]=\"filteredTasks[index].startDate\">\n        </div>\n      </div>\n\n      <div class=\"form-group required row\" style=\"margin-left:1.5%\">\n        <label for=\"endDate2\" class=\"col-sm-2 col-form-label\" style=\"white-space:nowrap\">End Date:</label>\n        <div class=\"col-md-6\">\n          <input type=\"date\" name=\"endDate2\" class=\"form-control\" placeholder=\"DD/MM/YYYY\" id=\"endDate2\"\n            [(ngModel)]=\"filteredTasks[index].endDate\">\n        </div>\n      </div>\n\n      <div class=\"form-group row\">\n        <div class=\"col-sm-4\"></div>\n        <button type=\"button\" class=\"btn btn-secondary btn-sm\" style=\"margin:10px\"\n          [disabled]=\"!(filteredTasks[index].taskName && filteredTasks[index].parentTask.parentTaskName && filteredTasks[index].startDate && filteredTasks[index].endDate && validateDate(index))\"\n          (click)=\"saveTask(index)\">Update</button>\n        <button type=\"button\" class=\"btn btn-secondary btn-sm\" style=\"margin:10px\" (click)=\"closeModal()\">Close</button>\n        <div class=\"col-sm-2\"></div>\n      </div>\n\n    </form>\n  </div>\n</ng-template>\n\n<ng-template #template2>\n  <div class=\"modal-header\">\n    <h4 class=\"modal-title pull-left\">Parent Task</h4>\n    <button type=\"button\" class=\"close pull-right\" aria-label=\"Close\" (click)=\"closeParentTaskModal()\">\n      <span aria-hidden=\"true\">&times;</span>\n    </button>\n  </div>\n  <div class=\"modal-body\" style=\"width:500px;height:500px\">\n    <div class=\"row\">\n      <div class=\"col-md-2\">\n        <label for=\"Search\" class=\"col-form-label-lg\" style=\"margin-left: 25%\">Search</label>\n      </div>\n      <div class=\"col-md-6\">\n        <input type=\"text\" name=\"parentTaskSearchValue\" class=\"form-control\" [(ngModel)]=\"parentTaskSearchValue\">\n      </div>\n    </div>\n    <div class=\"row\">\n      <div class=\"col-md-4\">\n        <label for=\"parentTaskName\" class=\"col-sm-3 col-form-label col-form-label-lg\" style=\"white-space:nowrap\">Parent\n          Task</label>\n      </div>\n\n      <div class=\"col-md-4\">\n        <label for=\"parentTaskId\" class=\"col-sm-4 col-form-label col-form-label-lg\"\n          style=\"white-space:nowrap;padding-left:5%\">Parent Task ID</label>\n      </div>\n\n      <div *ngFor=\"let parentTask of filteredParentTasks;let i = index\">\n        <div class=\"row\" id={{i}}>\n          <div class=\"col-md-4\">\n            <input type=\"text\" name=\"parentTaskName\" class=\"form-control\" id=\"parentTaskName\" disabled=true\n              value=\"{{parentTask.parentTaskName}}\" style=\"margin-left:20%\">\n          </div>\n          <div class=\"col-md-3\">\n            <input type=\"text\" name=\"parentId\" class=\"form-control\" id=\"parentId\" disabled=true\n              value=\"{{parentTask.parentTaskId}}\" style=\"margin-left:20%\">\n          </div>\n          <div class=\"col-md-3\" style=\"padding:1%\">\n            <button type=\"button\" id=\"select\" class=\"btn btn-secondary btn-sm\" (click)=\"selectParentTask(i)\"\n              style=\"margin-left:20%\">Select</button>\n          </div>\n        </div>\n      </div>\n\n    </div>\n  </div>\n</ng-template>\n\n<ng-template #template3>\n  <div class=\"modal-header\">\n    <h4 class=\"modal-title pull-left\">Project</h4>\n    <button type=\"button\" class=\"close pull-right\" aria-label=\"Close\" (click)=\"closeProjectModal()\">\n      <span aria-hidden=\"true\">&times;</span>\n    </button>\n  </div>\n  <div class=\"modal-body\" style=\"width:500px;height:500px\">\n    <div class=\"row\">\n      <div class=\"col-md-2\">\n        <label for=\"Search\" class=\"col-form-label-lg\" style=\"margin-left: 25%\">Search</label>\n      </div>\n      <div class=\"col-md-6\">\n        <input type=\"text\" name=\"projectSearchValue\" class=\"form-control\" [(ngModel)]=\"projectSearchValue\">\n      </div>\n    </div>\n    <div class=\"row\">\n      <div class=\"col-md-3\">\n        <label for=\"projectName2\" class=\"col-sm-3 col-form-label col-form-label-lg\">Project</label>\n      </div>\n      <div class=\"col-md-3\" style=\"padding-right:20px;padding-left:5px\">\n        <label for=\"projectName2\" class=\"col-sm-3 col-form-label col-form-label-lg\"\n          style=\"white-space:nowrap;padding-left:2px\">Start\n          Date</label>\n      </div>\n      <div class=\"col-md-3\">\n        <label for=\"projectName2\" class=\"col-sm-3 col-form-label col-form-label-lg\"\n          style=\"white-space:nowrap;padding-left:2px\">End\n          Date</label>\n      </div>\n\n      <div *ngFor=\"let project of filteredProjects;let i = index\">\n        <div class=\"row\" id={{i}}>\n          <div class=\"col-md-3\">\n            <input type=\"text\" name=\"projectName\" class=\"form-control\" id=\"projectName\" readonly\n              value=\"{{project.projectName}}\" style=\"margin-left:20%\">\n          </div>\n          <div class=\"col-md-3\" style=\"margin-left:0%\">\n            <input type=\"text\" name=\"startDate\" class=\"form-control\" id=\"startDate\" readonly\n              value=\"{{project.startDate}}\" style=\"padding-right:3px;\">\n          </div>\n          <div class=\"col-md-3\">\n            <input type=\"text\" name=\"endDate\" class=\"form-control\" id=\"endDate\" readonly value=\"{{project.endDate}}\"\n              style=\"padding-right:3px;padding-left:2px\">\n          </div>\n          <div class=\"col-md-3\" style=\"padding:1%\">\n            <button type=\"button\" id=\"select\" class=\"btn btn-secondary btn-sm\" (click)=\"selectProjectAndRelatedTasks(i)\"\n              style=\"margin-left:20%\">Select</button>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</ng-template>"

/***/ }),

/***/ "./src/app/components/task/view-task/view-task.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/components/task/view-task/view-task.component.ts ***!
  \******************************************************************/
/*! exports provided: ViewTaskComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewTaskComponent", function() { return ViewTaskComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var ngx_bootstrap_modal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ngx-bootstrap/modal */ "./node_modules/ngx-bootstrap/modal/fesm5/ngx-bootstrap-modal.js");
/* harmony import */ var src_app_services_project_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/project.service */ "./src/app/services/project.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var ViewTaskComponent = /** @class */ (function () {
    function ViewTaskComponent(projectService, modalService) {
        this.projectService = projectService;
        this.modalService = modalService;
        this._parentTaskSearchValue = "";
        this._projectSearchValue = "";
    }
    ViewTaskComponent.prototype.ngOnInit = function () {
        this.getTasks();
    };
    ViewTaskComponent.prototype.getTasks = function () {
        var _this = this;
        var obs = this.projectService.getTasks();
        obs.subscribe(function (response) {
            _this.taskList = response ? response.data : null;
            _this.filteredTasks = response ? response.data : null;
        }, function (error) { return _this.errorMsg = error; });
    };
    ViewTaskComponent.prototype.getParentTasks = function () {
        var _this = this;
        var obs = this.projectService.getParentTasks();
        obs.subscribe(function (response) {
            _this.parentTasks = response ? response.data : null;
            _this.filteredParentTasks = response ? response.data : null;
        }, function (error) { return _this.errorMsg = error; });
    };
    ViewTaskComponent.prototype.getProjects = function () {
        var _this = this;
        var obs = this.projectService.getProjects();
        obs.subscribe(function (response) {
            _this.projects = response ? response.data : null;
            _this.filteredProjects = response ? response.data : null;
        }, function (error) { return _this.errorMsg = error; });
    };
    ViewTaskComponent.prototype.saveTask = function (i) {
        var _this = this;
        this.projectService.saveOrUpdateTask(this.filteredTasks[i]).subscribe(function (response) {
            _this.closeModal();
        }, function (error) { return _this.errorMsg = error; });
    };
    ViewTaskComponent.prototype.endTask = function (i) {
        var _this = this;
        this.filteredTasks[i].taskCompleted = "Y";
        var obs = this.projectService.saveOrUpdateTask(this.filteredTasks[i]);
        obs.subscribe(function (res) { return _this.filteredTasks[i].taskCompleted = 'Y'; });
    };
    ViewTaskComponent.prototype.closeModal = function () {
        this.modalRef.hide();
    };
    ViewTaskComponent.prototype.openModal = function (template, i) {
        this.index = i;
        this.modalRef = this.modalService.show(template);
    };
    Object.defineProperty(ViewTaskComponent.prototype, "parentTaskSearchValue", {
        get: function () {
            return this._parentTaskSearchValue;
        },
        set: function (value) {
            this._parentTaskSearchValue = value;
            this.filteredParentTasks = this.parentTaskSearchValue ? this.performParentTaskFilter(this.parentTaskSearchValue) : this.parentTasks;
        },
        enumerable: true,
        configurable: true
    });
    ViewTaskComponent.prototype.performParentTaskFilter = function (filterValue) {
        filterValue = filterValue.toLocaleLowerCase();
        return this.parentTasks.filter(function (parentTask) { return parentTask.parentTaskName.toLocaleLowerCase().indexOf(filterValue) !== -1; });
    };
    ViewTaskComponent.prototype.openParentTaskModal = function (template) {
        this.getParentTasks();
        this.parentTaskModalRef = this.modalService.show(template);
    };
    ViewTaskComponent.prototype.closeParentTaskModal = function () {
        this.parentTaskModalRef.hide();
    };
    ViewTaskComponent.prototype.selectParentTask = function (i) {
        this.filteredTasks[i].parentTask = this.filteredParentTasks[i];
        this.closeParentTaskModal();
    };
    Object.defineProperty(ViewTaskComponent.prototype, "projectSearchValue", {
        get: function () {
            return this._projectSearchValue;
        },
        set: function (value) {
            this._projectSearchValue = value;
            this.filteredProjects = this.projectSearchValue ? this.performProjectFilter(this.projectSearchValue) : this.projects;
        },
        enumerable: true,
        configurable: true
    });
    ViewTaskComponent.prototype.performProjectFilter = function (filterValue) {
        filterValue = filterValue.toLocaleLowerCase();
        return this.projects.filter(function (project) { return project.projectName.toLocaleLowerCase().indexOf(filterValue) !== -1; });
    };
    ViewTaskComponent.prototype.openProjectModal = function (template) {
        this.getProjects();
        this.projectModalRef = this.modalService.show(template);
    };
    ViewTaskComponent.prototype.closeProjectModal = function () {
        this.projectModalRef.hide();
    };
    ViewTaskComponent.prototype.selectProjectAndRelatedTasks = function (i) {
        this.projectId = this.filteredProjects[i].projectId;
        this.filteredTasks = this.taskList;
        this.setRelatedTasks(this.projectId);
        this.closeProjectModal();
    };
    ViewTaskComponent.prototype.validateDate = function (i) {
        var startDateStr = this.filteredTasks[i].startDate;
        var endDateStr = this.filteredTasks[i].endDate;
        var startDate = new Date(startDateStr);
        var endDate = new Date(endDateStr);
        var flag = false;
        if (endDate.getTime() >= startDate.getTime()) {
            flag = true;
        }
        return flag;
    };
    ViewTaskComponent.prototype.setRelatedTasks = function (projectId) {
        this.filteredTasks = this.filteredTasks.filter(function (task) { return task.project.projectId === projectId; });
    };
    ViewTaskComponent.prototype.sortByStartDate = function () {
        this.filteredTasks.sort(function (a, b) {
            var date1 = new Date(a.startDate);
            var date2 = new Date(b.startDate);
            if (date1 > date2)
                return -1;
            if (date1 < date2)
                return 1;
            return 0;
        });
    };
    ViewTaskComponent.prototype.sortByEndDate = function () {
        this.filteredTasks.sort(function (a, b) {
            var date1 = new Date(a.endDate);
            var date2 = new Date(b.endDate);
            if (date1 > date2)
                return -1;
            if (date1 < date2)
                return 1;
            return 0;
        });
    };
    ViewTaskComponent.prototype.sortByPriority = function () {
        this.filteredTasks.sort(function (a, b) {
            var value1 = a.priority;
            var value2 = b.priority;
            return value2 - value1;
        });
    };
    ViewTaskComponent.prototype.sortByCompletion = function () {
        this.filteredTasks.sort(function (a, b) {
            var value1 = a.taskCompleted.toLocaleLowerCase();
            var value2 = b.taskCompleted.toLocaleLowerCase();
            if (value1 < value2)
                return -1;
            if (value1 > value2)
                return 1;
            return 0;
        });
    };
    ViewTaskComponent.prototype.reset = function () {
        this.projectId = "";
        this.filteredTasks = this.taskList;
    };
    ViewTaskComponent.prototype.onKey = function (event, i) {
        this.filteredTasks[i].priority = event.target.value;
    };
    ViewTaskComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-view-task',
            template: __webpack_require__(/*! ./view-task.component.html */ "./src/app/components/task/view-task/view-task.component.html"),
            styles: [__webpack_require__(/*! ./view-task.component.css */ "./src/app/components/task/view-task/view-task.component.css")]
        }),
        __metadata("design:paramtypes", [src_app_services_project_service__WEBPACK_IMPORTED_MODULE_2__["ProjectService"], ngx_bootstrap_modal__WEBPACK_IMPORTED_MODULE_1__["BsModalService"]])
    ], ViewTaskComponent);
    return ViewTaskComponent;
}());



/***/ }),

/***/ "./src/app/components/user/add-user/add-user.component.css":
/*!*****************************************************************!*\
  !*** ./src/app/components/user/add-user/add-user.component.css ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/user/add-user/add-user.component.html":
/*!******************************************************************!*\
  !*** ./src/app/components/user/add-user/add-user.component.html ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<form class=\"needs-validation\" novalidate>\n\n  <div class=\"form-group row required\" style=\"margin-left:1%\">\n    <div class=\"col-md-1\">\n      <label for=\"firstName\" class=\"col-sm-2 col-form-label col-form-label-lg\" style=\"padding-left:.1%;white-space:nowrap\">First\n        Name:</label>\n    </div>\n    <div class=\"col-md-5\">\n      <input type=\"text\" class=\"form-control\" id=\"firstName\" name=\"firstName\" [(ngModel)]=\"user.firstName\">\n    </div>\n  </div>\n\n  <div class=\"form-group row required\" style=\"margin-left:1%\">\n    <div class=\"col-md-1\">\n      <label for=\"lastName\" class=\"col-sm-2 col-form-label col-form-label-lg\" style=\"padding-left:.1%;white-space:nowrap\">Last\n        Name:</label>\n    </div>\n    <div class=\"col-md-5\">\n      <input type=\"text\" class=\"form-control\" id=\"lastName\" name=\"firstName\" [(ngModel)]=\"user.lastName\">\n    </div>\n  </div>\n\n  <div class=\"form-group row\" style=\"margin-left:.8%\">\n    <div class=\"col-md-1\">\n      <label for=\"employeeId\" class=\"col-sm-2 col-form-label col-form-label-lg\" style=\"padding-left:.1%;white-space:nowrap\">Employee\n        ID:</label>\n    </div>\n    <div class=\"col-md-5\">\n      <input type=\"text\" class=\"form-control\" id=\"employeeId\" name=\"employeeId\" [(ngModel)]=\"user.empId\" style=\"margin-left:1%\">\n    </div>\n  </div>\n\n  <div class=\"form-group row\" style=\"margin-left:1%\">\n    <div class=\"col-md-3\">\n    </div>\n    <div class=\"col-md-2\" style=\"padding-left:10%;padding-right:1%\">\n      <button type=\"button\" id=\"add\" class=\"btn btn-secondary btn-sm\"\n        [disabled]=\"!(user.firstName && user.lastName && user.empId)\" (click)=\"saveOrUpdateUser()\" style=\"width:100%\">Add</button>\n    </div>\n    <div class=\"col-md-3\" style=\"padding-left:0%;padding-right:1%\">\n      <button type=\"button\" id=\"reset\" class=\"btn btn-secondary btn-sm\" style=\"width:25%\" (click)=\"reset()\">Reset</button>\n    </div>\n  </div>\n\n</form>\n\n<div class=\"col-md-6\" style=\"margin-left:1%\">\n  <hr style=\"border:1px solid#7f797961\"/>\n</div>\n\n<div class=\"row\" style=\"margin-left:.1%\">\n  <div class=\"col-md-1\">\n    <label for=\"Search\" class=\"col-sm-1 col-form-label col-form-label-lg\">Search</label>\n  </div>\n  <div class=\"col-md-2\">\n    <input type=\"text\" name=\"userSearchValue\" class=\"form-control\" id=\"userSearchValue\" [(ngModel)]=\"userSearchValue\">\n  </div>\n  <div class=\"col-md-7\">\n    <label for=\"sort\" class=\"col-sm-1 col-form-label col-form-label-lg\">Sort:</label>\n    <span>\n      <button type=\"button\" id=\"firstName\" class=\"btn btn-secondary btn-sm\" style=\"margin-left:2%\"\n      (click)=\"sortByFirstName()\">First Name</button>\n    </span>\n    <span>\n      <button type=\"button\" id=\"lastName\" class=\"btn btn-secondary btn-sm\" style=\"margin-left:2%\"\n      (click)=\"sortByLastName()\">Last Name</button>\n    </span>\n    <span>\n      <button type=\"button\" id=\"id\" class=\"btn btn-secondary btn-sm\" style=\"margin-left:2%\"\n      (click)=\"sortById()\">Id</button>\n    </span>\n  </div>\n \n</div>\n\n<div *ngFor=\"let user of filteredUsers;let i=index\">\n  <div class=\"col-md-6\" style=\"margin-left:1%\">\n    <hr style=\"border-top: dotted 1px;\" />\n  </div>\n  <div class=\"row\" style=\"margin-left:1%\">\n    <div class=\"col-md-4\">\n      <input type=\"text\" class=\"form-control\" id=\"firstName\" name=\"firstName\" [(ngModel)]=\"user.firstName\" readonly>\n    </div>\n    <div class=\"col-md-2\" style=\"padding-left: 10%\">\n      <button type=\"button\" id=\"add\" class=\"btn btn-secondary btn-sm\" (click)=\"openUserMdal(template,i)\" style=\"width: 100%;padding-left:10%\">Edit</button>\n    </div>\n  </div>\n  <div class=\"row\" style=\"margin-left:1%\">\n      <div class=\"col-md-4\">\n        <input type=\"text\" class=\"form-control\" id=\"lastName\" name=\"lastName\" [(ngModel)]=\"user.lastName\" readonly>\n      </div>\n      <div class=\"col-md-2\" style=\"padding-left: 10%\">\n          <button type=\"button\" id=\"add\" class=\"btn btn-secondary btn-sm\" (click)=\"deleteUser(i)\" style=\"width: 100%\">Delete</button>\n      </div>\n  </div>\n  <div class=\"row\" style=\"margin-left:1%\">\n    <div class=\"col-md-4\">\n      <input type=\"text\" class=\"form-control\" id=\"employeeId\" name=\"employeeId\" [(ngModel)]=\"user.empId\" readonly>\n    </div>    \n  </div>\n</div>\n\n<ng-template #template>\n  <div class=\"modal-header\">\n    <h4 class=\"modal-title pull-left\">Update User</h4>\n    <button type=\"button\" class=\"close pull-right\" aria-label=\"Close\" (click)=\"closeUserModal()\">\n      <span aria-hidden=\"true\">&times;</span>\n    </button>\n  </div>\n  <div class=\"modal-body\" style=\"width:500px;height:500px\">\n    \n    <div class=\"form-group row\">\n      <div class=\"col-md-2\">\n        <label for=\"name\" class=\"col-form-label-lg\" style=\"white-space:nowrap\">First Name:</label>\n      </div>\n      <div class=\"col-md-7\" style=\"margin-left:10%\">\n        <input type=\"text\" name=\"firstName2\" class=\"form-control\" id=\"firstName2\" \n        [(ngModel)]=\"filteredUsers[index].firstName\" />\n      </div>\n    </div>\n    <div class=\"form-group row\">  \n      <div class=\"col-md-2\">\n        <label for=\"name\" class=\"col-form-label-lg\" style=\"white-space:nowrap\">Last Name:</label>\n      </div>\n      <div class=\"col-md-7\" style=\"margin-left:10%\">\n        <input type=\"text\" name=\"lastName2\" class=\"form-control\" id=\"lastName2\" \n        [(ngModel)]=\"filteredUsers[index].lastName\" />\n      </div>\n    </div>\n    <div class=\"form-group row\">\n      <div class=\"col-md-2\">\n        <label for=\"empId\" class=\"col-form-label-lg\" style=\"white-space:nowrap\">Emp ID:</label>\n      </div>\n      <div class=\"col-md-7\" style=\"margin-left:10%\">\n        <input type=\"text\" name=\"empId2\" class=\"form-control\" id=\"empId2\"  [(ngModel)]=\"filteredUsers[index].empId\">\n      </div>\n    </div> \n    \n    <div class=\"form-group row\">\n      <div class=\"col-sm-6\"></div>\n        <button type=\"button\" class=\"btn btn-secondary btn-sm\" style=\"margin:10px\"\n          [disabled]=\"!(filteredUsers[index].firstName && filteredUsers[index].lastName && filteredUsers[index].empId)\"\n          (click)=\"updateUser(index)\">Update</button>\n        <button type=\"button\" class=\"btn btn-secondary btn-sm\" style=\"margin:10px\" (click)=\"closeUserModal()\">Close</button>\n      <div class=\"col-sm-2\"></div>\n    </div>\n  </div>\n</ng-template>"

/***/ }),

/***/ "./src/app/components/user/add-user/add-user.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/components/user/add-user/add-user.component.ts ***!
  \****************************************************************/
/*! exports provided: AddUserComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddUserComponent", function() { return AddUserComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var ngx_bootstrap_modal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ngx-bootstrap/modal */ "./node_modules/ngx-bootstrap/modal/fesm5/ngx-bootstrap-modal.js");
/* harmony import */ var src_app_model_user__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/model/user */ "./src/app/model/user.ts");
/* harmony import */ var src_app_services_project_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/project.service */ "./src/app/services/project.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var AddUserComponent = /** @class */ (function () {
    function AddUserComponent(modalService, projectService) {
        this.modalService = modalService;
        this.projectService = projectService;
        this._userSearchValue = "";
        this.user = new src_app_model_user__WEBPACK_IMPORTED_MODULE_2__["User"]();
    }
    AddUserComponent.prototype.ngOnInit = function () {
        this.getUsers();
    };
    AddUserComponent.prototype.saveOrUpdateUser = function () {
        var _this = this;
        console.log("User---> " + JSON.stringify(this.user));
        this.projectService.saveOrUpdateUser(this.user).subscribe(function (response) {
            //this.filteredUsers.push(this.user);
            _this.getUsers();
            _this.reset();
        }, function (error) { return _this.errorMsg = error; });
    };
    AddUserComponent.prototype.updateUser = function (i) {
        var _this = this;
        this.projectService.saveOrUpdateUser(this.filteredUsers[i]).subscribe(function (response) {
            _this.closeUserModal();
        }, function (error) { return _this.errorMsg = error; });
    };
    AddUserComponent.prototype.deleteUser = function (i) {
        var _this = this;
        this.filteredUsers[i].active = "N";
        this.projectService.saveOrUpdateUser(this.filteredUsers[i]).subscribe(function (response) {
            _this.getUsers();
        }, function (error) { return _this.errorMsg = error; });
    };
    AddUserComponent.prototype.getUsers = function () {
        var _this = this;
        var obs = this.projectService.getUsers();
        obs.subscribe(function (response) {
            _this.users = response ? response.data : null;
            _this.filteredUsers = response ? response.data : null;
        }, function (error) { return _this.errorMsg = error; });
    };
    Object.defineProperty(AddUserComponent.prototype, "userSearchValue", {
        get: function () {
            return this._userSearchValue;
        },
        set: function (value) {
            this._userSearchValue = value;
            this.filteredUsers = this.userSearchValue ? this.performUserFilter(this.userSearchValue) : this.users;
        },
        enumerable: true,
        configurable: true
    });
    AddUserComponent.prototype.performUserFilter = function (filterValue) {
        filterValue = filterValue.toLocaleLowerCase();
        return this.users.filter(function (user) { return user.firstName.toLocaleLowerCase().indexOf(filterValue) !== -1; });
    };
    AddUserComponent.prototype.openUserMdal = function (template, i) {
        this.index = i;
        this.modalRef = this.modalService.show(template);
    };
    AddUserComponent.prototype.closeUserModal = function () {
        this.getUsers();
        this.modalRef.hide();
    };
    AddUserComponent.prototype.sortByFirstName = function () {
        this.filteredUsers.sort(function (a, b) {
            var value1 = a.firstName.toLocaleLowerCase();
            var value2 = b.firstName.toLocaleLowerCase();
            return value1.localeCompare(value2);
        });
    };
    AddUserComponent.prototype.sortByLastName = function () {
        this.filteredUsers.sort(function (a, b) {
            var value1 = a.lastName.toLocaleLowerCase();
            var value2 = b.lastName.toLocaleLowerCase();
            return value1.localeCompare(value2);
        });
    };
    AddUserComponent.prototype.sortById = function () {
        this.filteredUsers.sort(function (a, b) {
            var value1 = a.empId.toLocaleLowerCase();
            var value2 = b.empId.toLocaleLowerCase();
            return value1.localeCompare(value2);
        });
    };
    AddUserComponent.prototype.selectUser = function (i) {
        this.modalRef.hide();
    };
    AddUserComponent.prototype.reset = function () {
        this.user.firstName = "";
        this.user.userId = "";
        this.user.lastName = "";
        this.user.empId = "";
    };
    AddUserComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-add-user',
            template: __webpack_require__(/*! ./add-user.component.html */ "./src/app/components/user/add-user/add-user.component.html"),
            styles: [__webpack_require__(/*! ./add-user.component.css */ "./src/app/components/user/add-user/add-user.component.css")]
        }),
        __metadata("design:paramtypes", [ngx_bootstrap_modal__WEBPACK_IMPORTED_MODULE_1__["BsModalService"], src_app_services_project_service__WEBPACK_IMPORTED_MODULE_3__["ProjectService"]])
    ], AddUserComponent);
    return AddUserComponent;
}());



/***/ }),

/***/ "./src/app/constants/project-constant.ts":
/*!***********************************************!*\
  !*** ./src/app/constants/project-constant.ts ***!
  \***********************************************/
/*! exports provided: ProjectConstant */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectConstant", function() { return ProjectConstant; });
var ProjectConstant = /** @class */ (function () {
    function ProjectConstant() {
    }
    /*public static FETCH_TASKS: string = '/server/api/projectmanager/getTasks';
    public static FETCH_PROJECTS: string = '/server/api/projectmanager/getProjects';
    public static FETCH_USERS: string = '/server/api/projectmanager/getUsers';
    public static FETCH_PARENT_TASKS: string = '/server/api/projectmanager/getParentTasks';

    public static SAVE_PROJECT: string = '/server/api/projectmanager/saveProject';
    public static SAVE_TASK: string = '/server/api/projectmanager/saveTask';
    public static SAVE_USER: string = '/server/api/projectmanager/saveUser';
    public static DELETE_USER: string = '/server/api/projectmanager/deleteUser';*/
    ProjectConstant.FETCH_TASKS = 'http://localhost:8080/project-manager-service/api/projectmanager/getTasks';
    ProjectConstant.FETCH_PROJECTS = 'http://localhost:8080/project-manager-service/api/projectmanager/getProjects';
    ProjectConstant.FETCH_USERS = 'http://localhost:8080/project-manager-service/api/projectmanager/getUsers';
    ProjectConstant.FETCH_PARENT_TASKS = 'http://localhost:8080/project-manager-service/api/projectmanager/getParentTasks';
    ProjectConstant.SAVE_PROJECT = 'http://localhost:8080/project-manager-service/api/projectmanager/saveProject';
    ProjectConstant.SAVE_TASK = 'http://localhost:8080/project-manager-service/api/projectmanager/saveTask';
    ProjectConstant.SAVE_USER = 'http://localhost:8080/project-manager-service/api/projectmanager/saveUser';
    ProjectConstant.DELETE_USER = 'http://localhost:8080/project-manager-service/api/projectmanager/deleteUser';
    return ProjectConstant;
}());



/***/ }),

/***/ "./src/app/model/pm-parent-task.ts":
/*!*****************************************!*\
  !*** ./src/app/model/pm-parent-task.ts ***!
  \*****************************************/
/*! exports provided: PmParentTask */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PmParentTask", function() { return PmParentTask; });
var PmParentTask = /** @class */ (function () {
    function PmParentTask() {
    }
    return PmParentTask;
}());



/***/ }),

/***/ "./src/app/model/pm-task.ts":
/*!**********************************!*\
  !*** ./src/app/model/pm-task.ts ***!
  \**********************************/
/*! exports provided: PmTask */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PmTask", function() { return PmTask; });
/* harmony import */ var _pm_parent_task__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pm-parent-task */ "./src/app/model/pm-parent-task.ts");

var PmTask = /** @class */ (function () {
    function PmTask() {
        this.priority = 0;
        this.parentTask = new _pm_parent_task__WEBPACK_IMPORTED_MODULE_0__["PmParentTask"]();
        this.taskCompleted = "N";
    }
    return PmTask;
}());



/***/ }),

/***/ "./src/app/model/project.ts":
/*!**********************************!*\
  !*** ./src/app/model/project.ts ***!
  \**********************************/
/*! exports provided: Project */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Project", function() { return Project; });
var Project = /** @class */ (function () {
    function Project() {
        this.priority = 0;
        this.projectCompleted = "N";
    }
    return Project;
}());



/***/ }),

/***/ "./src/app/model/user.ts":
/*!*******************************!*\
  !*** ./src/app/model/user.ts ***!
  \*******************************/
/*! exports provided: User */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "User", function() { return User; });
var User = /** @class */ (function () {
    function User() {
        this.active = "Y";
    }
    Object.defineProperty(User.prototype, "fullName", {
        get: function () {
            return this._fullName;
        },
        set: function (value) {
            this._fullName = value;
        },
        enumerable: true,
        configurable: true
    });
    return User;
}());



/***/ }),

/***/ "./src/app/services/project.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/project.service.ts ***!
  \*********************************************/
/*! exports provided: ProjectService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectService", function() { return ProjectService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _constants_project_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../constants/project-constant */ "./src/app/constants/project-constant.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var ProjectService = /** @class */ (function () {
    function ProjectService(http) {
        this.http = http;
    }
    ProjectService.prototype.getProjects = function () {
        return this.http.get(_constants_project_constant__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].FETCH_PROJECTS).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (data) {
        }, Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError)));
    };
    ProjectService.prototype.getUsers = function () {
        var _this = this;
        return this.http.get(_constants_project_constant__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].FETCH_USERS).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (data) {
            return Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(_this.handleError);
        }));
    };
    ProjectService.prototype.getParentTasks = function () {
        var _this = this;
        return this.http.get(_constants_project_constant__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].FETCH_PARENT_TASKS).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (data) {
            return Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(_this.handleError);
        }));
    };
    ProjectService.prototype.getTasks = function () {
        return this.http.get(_constants_project_constant__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].FETCH_TASKS).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (data) {
        }, Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError)));
    };
    ProjectService.prototype.saveOrUpdateProject = function (project) {
        var _this = this;
        return this.http.post(_constants_project_constant__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].SAVE_PROJECT, project, httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (data) {
            return Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(_this.handleError);
        }));
    };
    ProjectService.prototype.saveOrUpdateTask = function (task) {
        var _this = this;
        return this.http.post(_constants_project_constant__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].SAVE_TASK, task, httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (data) {
            return Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(_this.handleError);
        }));
    };
    ProjectService.prototype.saveOrUpdateUser = function (user) {
        var _this = this;
        return this.http.post(_constants_project_constant__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].SAVE_USER, user, httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (data) {
            return Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(_this.handleError);
        }));
    };
    ProjectService.prototype.endTask = function (task) {
        return this.http.post(_constants_project_constant__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].SAVE_TASK, task, httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (data) { }, Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError)));
    };
    ProjectService.prototype.deleteUser = function (user) {
        var _this = this;
        return this.http.post(_constants_project_constant__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].DELETE_USER, user, httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (data) {
            return Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(_this.handleError);
        }));
    };
    ProjectService.prototype.handleError = function (err) {
        var errMsg = '';
        if (err.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            errMsg = "An error occurred: " + err.error.message;
        }
        else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            errMsg = "Server returned code: " + err.status + ", error message is: " + err.message;
        }
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["throwError"])(errMsg);
    };
    ProjectService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], ProjectService);
    return ProjectService;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! E:\Work_Space\IIHT\Final_UI\project-manager-ui\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map